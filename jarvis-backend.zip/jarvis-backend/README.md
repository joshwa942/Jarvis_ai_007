# JARVIS Backend — Module 1: Telegram Connector

Your personal AI assistant's brain + first connector. Telegram messages go in,
Groq (llama-3.1-8b-instant) thinks, tools execute real actions, replies go back.

## What's included
- Express server with a Telegram webhook route
- Groq function-calling brain (`llama-3.3-70b-versatile` by default — a
  significant quality step up from the earlier 8b model) with short-term
  per-chat memory
- Tools: `set_reminder`, `send_email`, `read_inbox`, `add_task`, `list_tasks`,
  `complete_task`, `build_project`
- Persistent task list (`tasks.json`) that survives server restarts
- Automatic daily task digest sent to you every morning on Telegram
- Voice mode: send a voice note on Telegram → JARVIS transcribes it (Groq Whisper),
  thinks, and replies back as a voice note (Google TTS) — no text involved
- Build agent: ask JARVIS to build something (an app, script, website, game,
  tool) and it generates the code, zips it, and sends the zip as a file on
  Telegram — no need to open a code editor
- **Smart long-answer delivery: if an answer is too long for a normal Telegram
  message, JARVIS automatically sends it as a `.txt` file instead of cutting
  it off**
- Owner-lock so only your Telegram account can talk to it

## 1. Fill in the missing pieces in `.env`
- `GROQ_API_KEY` — get a free key at https://console.groq.com/keys
- `TELEGRAM_BOT_TOKEN` — already filled in with the token you gave me
- `OWNER_TELEGRAM_ID` — leave blank for now, see step 4
- `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` — from Google Cloud Console (see "Gmail setup" below)
- `GOOGLE_REDIRECT_URI` — already set to `http://localhost:3000/auth/google/callback` for local testing

## 2. Install and run locally
```bash
npm install
npm start
```
You should see `JARVIS backend listening on port 3000`.

## 3. Expose it to the internet (required — Telegram needs HTTPS)
For local testing, use [ngrok](https://ngrok.com):
```bash
ngrok http 3000
```
Copy the `https://xxxx.ngrok-free.app` URL it gives you.

For a permanent setup, deploy this folder to Render, Railway, or a VPS instead —
same code, just set the same `.env` variables there.

## 4. Register the webhook with Telegram
Visit in your browser (replace with your real public URL):
```
https://xxxx.ngrok-free.app/webhook/setup?url=https://xxxx.ngrok-free.app/webhook/telegram
```
You should get back `{"ok":true,"result":true,...}`.

## 5. Lock it to yourself
- Open Telegram, message your bot anything (e.g. "hi")
- Check your server console — it logs `message from <fromId> (chat <chatId>)`
- Copy that numeric ID into `OWNER_TELEGRAM_ID` in `.env`
- Restart the server

Now only you can command JARVIS; anyone else who finds the bot gets a polite refusal.

## 6. Test it
Message your bot on Telegram:
- `"Hey, remind me in 2 minutes to check the oven"` → it should call `set_reminder`
  and message you back in 2 minutes
- `"Add a task: buy groceries, due today evening"` → triggers `add_task`
- `"What are my pending tasks?"` → triggers `list_tasks`
- `"Mark task 1 as done"` → triggers `complete_task`
- `"What's the capital of France?"` → plain conversational reply, no tool used

Every morning at the time set by `DAILY_DIGEST_HOUR`/`DAILY_DIGEST_MINUTE`
(default 8:00 AM server time), JARVIS will message you your pending task list
automatically — no need to ask.

## Voice mode
Hold the mic button on Telegram, ask JARVIS anything by speaking (Tanglish or
English), and send it as a voice note. JARVIS will:
1. Transcribe it using Groq's Whisper model (no extra API key — reuses `GROQ_API_KEY`)
2. Run it through the same brain/tools as a typed message
3. Convert the reply to speech and send it back as a voice note — text messages
   still get text replies as before; only voice-in gets voice-out

No setup needed beyond what you already have. Note: the text-to-speech voice
reads Tanglish phonetically as English (there's no good free TTS for
Tamil-in-English-letters), so pronunciation of Tamil words will sound a bit
off — fully understandable, just not native-accent.

## Build agent
Ask JARVIS to build something, e.g.:
- `"Build me a simple pomodoro timer webpage"`
- `"Make a tic-tac-toe game in HTML"`
- `"Create a script that renames files in a folder to lowercase"`

JARVIS will:
1. Generate the complete code (using Groq, no extra key needed)
2. Write it to `builds/<id>/` on the server and zip it
3. Send the `.zip` straight to your Telegram chat as a downloadable file

**Known limitations:**
- Uses the same `llama-3.1-8b-instant` model as the chat brain — great for
  small single-file tools (HTML pages, simple scripts, small games), but
  don't expect it to reliably generate large multi-file apps or complex
  backends. Keep build requests scoped and specific for best results.
- Generated projects are **not reviewed or tested** before being sent — treat
  them as a fast draft to open and check yourself, not production code.
- Each build is saved locally under `builds/` (gitignored) but not auto-cleaned;
  clear old ones periodically if disk space matters on your host.

## General Q&A + long answers
JARVIS now runs on `llama-3.3-70b-versatile` (upgradeable via `GROQ_MODEL` in
`.env` — check current options at console.groq.com/docs/models) and is
instructed to give full, complete answers for anything that needs depth
(explanations, comparisons, how-to guides, code, long lists), not just short
chat replies.

Because Telegram messages cap out around 4096 characters, any answer over
~3500 characters is automatically sent as a `jarvis-answer.txt` file instead
of a chat bubble — so nothing gets cut off, however long the question's
answer needs to be. Try asking something that needs a long answer (e.g.
`"Explain how OAuth 2.0 works in detail"`) and you should get a `.txt` file
back instead of a wall of text or a truncated message.

## Known limitations (fine for personal use, worth knowing)
- Reminders are in-memory — if the server restarts, pending reminders are lost.
  Tasks (`add_task`/`list_tasks`) ARE persisted to `tasks.json`, so those survive restarts.
- Conversation memory is in-memory per chat, capped at ~30 messages, and resets
  on server restart. Add Redis/Postgres later if you want persistent memory.
- `tool_choice: 'auto'` — the model decides when to use tools. If it's not
  triggering a tool reliably, tighten the tool description or force
  `tool_choice: 'required'` when you expect an action.
- The daily digest scheduler runs as a `setInterval` inside the same process —
  if you deploy behind something that restarts the server, timing resets but
  won't double-send (it tracks the date it last sent).

## Gmail setup (Module 2)
1. In Google Cloud Console, enable the **Gmail API**, configure the OAuth
   consent screen (External, add yourself as a test user), and create an
   **OAuth Client ID** (Web application) with redirect URI
   `http://localhost:3000/auth/google/callback`
2. Put the Client ID and Secret into `.env`
3. Start the server (`npm start`), then open `http://localhost:3000/auth/google`
   in your browser and approve access with your Google account
4. You'll see "✅ Gmail connected" — a `tokens.json` file is created locally
   (never commit this, it's already in `.gitignore`)
5. Test on Telegram:
   - `"Enakku vandha last 5 unread mails enna nu sollu"` → triggers `read_inbox`
   - `"[someone]@email.com ku 'meeting confirm' subject la 'sari, 4pm ok' nu mail anupu"` → triggers `send_email`

Notes:
- Since the Google app is in "Testing" mode, only test users you added can
  authorize it — that's fine, you're the only user
- Refresh tokens don't expire in testing mode unless unused for 6 months
- If you redeploy to a real domain later, add that domain's callback URL to
  both the Google Cloud OAuth client and `GOOGLE_REDIRECT_URI` in `.env`

## Next module
Instagram connector: Business/Creator account + Meta Graph API for posting
and comment/DM replies within Meta's allowed automation scope. Say the word
when you're ready.

## Bugfixes from the latest debugging pass
A full review of every file found and fixed these real issues:

1. **Daily digest fired at the wrong time when deployed outside India.**
   It used the server's system clock — most cloud hosts (Render, Railway,
   etc.) run in UTC, so an "8 AM" digest would've silently fired at 1:30 PM
   IST instead. Fixed to always compute the time in `DIGEST_TIMEZONE`
   (default `Asia/Kolkata`), regardless of the host's own timezone. Verified
   with a test forcing the server clock to UTC.
2. **A single failed tool call could permanently break a chat.** If e.g.
   `send_email` failed (Gmail not connected) or `build_project` errored, the
   conversation history was left with a tool-call request that never got a
   response — every future message in that chat would then fail with an API
   error until the server restarted. Fixed: every tool call now always gets
   a result message, even on failure (the model gets told what went wrong
   and explains it to you in Tanglish instead).
3. **Long Telegram messages containing underscores/asterisks could fail to
   send.** Telegram's Markdown mode treats `_..._` and `*...*` as formatting;
   unbalanced ones (common in filenames, code, build summaries) caused the
   whole message to be rejected. Fixed: `sendMessage` now retries as plain
   text automatically if Markdown parsing fails, instead of losing the reply.
4. **Chained tool calls weren't supported.** If the model wanted to call a
   second tool after seeing the first tool's result (e.g. add a task, then
   list tasks to confirm), the old code only handled one round trip and
   would silently return "(no response)". Now loops up to 4 rounds.
5. **History trimming could split a tool_calls/tool pair**, which would
   corrupt the next API call. Fixed to only ever cut at a `user` message
   boundary.
6. **A corrupted `tasks.json` or `tokens.json`** (e.g. from a crash mid-write)
   would crash every future task or Gmail operation. Both now log a warning
   and recover gracefully instead of throwing.
7. **Voice replies had no length cap** — a very long answer would try to
   speak the entire thing as one long voice note. Capped at ~1800 characters
   with a note to ask via text for the full answer.

All fixes were verified with isolated logic tests (timezone math against a
forced-UTC clock, history trimming against a simulated 60-message history,
tool-failure handling, and the Markdown-fallback retry path) plus a full
server boot test. Everything currently in this project boots cleanly and
passes those checks.
