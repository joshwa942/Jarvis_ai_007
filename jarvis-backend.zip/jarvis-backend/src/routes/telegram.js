const express = require('express');
const { sendMessage, sendTyping, setWebhook, getWebhookInfo, downloadFile, sendAudio, sendSmartReply } = require('../services/telegramService');
const { chat } = require('../services/groqService');
const { transcribeAudio } = require('../services/sttService');
const { synthesizeSpeech } = require('../services/ttsService');

const router = express.Router();

/**
 * Telegram calls this URL for every incoming message once the webhook is set.
 */
router.post('/telegram', async (req, res) => {
  // Acknowledge immediately so Telegram doesn't retry/timeout
  res.sendStatus(200);

  const message = req.body?.message;
  if (!message) return;

  const chatId = message.chat.id;
  const fromId = message.from?.id;

  const ownerId = process.env.OWNER_TELEGRAM_ID;
  if (ownerId && String(fromId) !== String(ownerId)) {
    console.warn(`[telegram] ignored message from non-owner id ${fromId}`);
    if (message.text || message.voice) {
      await sendMessage(chatId, "Sorry da, idhu private assistant, unakku access illa.");
    }
    return;
  }

  try {
    if (message.voice) {
      // Voice question in → voice answer out, no text reply
      console.log(`[telegram] voice message from ${fromId} (chat ${chatId})`);
      await sendTyping(chatId);

      const audioBuffer = await downloadFile(message.voice.file_id);
      const transcript = await transcribeAudio(audioBuffer, 'voice.ogg');
      console.log(`[telegram] transcribed: ${transcript}`);

      const replyText = await chat(chatId, transcript);
      const speech = await synthesizeSpeech(replyText);
      await sendAudio(chatId, speech, 'jarvis-reply.mp3');
      return;
    }

    if (message.text) {
      console.log(`[telegram] message from ${fromId} (chat ${chatId}): ${message.text}`);
      await sendTyping(chatId);
      const reply = await chat(chatId, message.text);
      await sendSmartReply(chatId, reply);
    }
  } catch (err) {
    console.error('[telegram] error handling message:', err);
    await sendMessage(chatId, '⚠️ Something went wrong processing that. Check the server logs.');
  }
});

/**
 * One-time setup helper: call this after deploying to register your
 * public HTTPS URL with Telegram as the webhook target.
 * Example: GET /webhook/setup?url=https://your-domain.com/webhook/telegram
 */
router.get('/setup', async (req, res) => {
  const { url } = req.query;
  if (!url) {
    return res.status(400).json({ error: 'Pass ?url=https://your-domain.com/webhook/telegram' });
  }
  const result = await setWebhook(url);
  res.json(result);
});

router.get('/info', async (req, res) => {
  const info = await getWebhookInfo();
  res.json(info);
});

module.exports = router;
