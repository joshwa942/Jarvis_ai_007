const express = require('express');
const { getAuthUrl, exchangeCodeForTokens, isConnected } = require('../services/googleAuthService');

const router = express.Router();

// Visit this once in your browser to connect your Gmail account
router.get('/google', (req, res) => {
  res.redirect(getAuthUrl());
});

// Google redirects here after you approve access
router.get('/google/callback', async (req, res) => {
  const { code, error } = req.query;
  if (error) return res.status(400).send(`Google auth error: ${error}`);
  if (!code) return res.status(400).send('Missing authorization code');

  try {
    await exchangeCodeForTokens(code);
    res.send('✅ Gmail connected. You can close this tab and go back to Telegram.');
  } catch (err) {
    console.error('[auth] callback failed:', err);
    res.status(500).send(`Failed to connect Gmail: ${err.message}`);
  }
});

router.get('/google/status', (req, res) => {
  res.json({ connected: isConnected() });
});

module.exports = router;
