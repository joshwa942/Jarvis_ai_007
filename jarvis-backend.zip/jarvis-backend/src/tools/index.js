const fs = require('fs');
const { sendMessage, sendDocument } = require('../services/telegramService');
const gmailService = require('../services/gmailService');
const taskService = require('../services/taskService');
const buildService = require('../services/buildService');
const websiteService = require('../services/websiteService');

/**
 * Tool schema list, passed to Groq's function-calling API.
 * Add new tools here as you connect more platforms (Instagram, WhatsApp, etc.)
 */
const toolDefinitions = [
  {
    type: 'function',
    function: {
      name: 'set_reminder',
      description:
        'Schedule a reminder message to be sent back to the user after a delay. Use this whenever the user asks to be reminded of something.',
      parameters: {
        type: 'object',
        properties: {
          delay_minutes: {
            type: 'number',
            description: 'How many minutes from now to send the reminder.',
          },
          message: {
            type: 'string',
            description: 'The reminder text to send back to the user.',
          },
        },
        required: ['delay_minutes', 'message'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'send_email',
      description: 'Send an email from the owner\'s Gmail account.',
      parameters: {
        type: 'object',
        properties: {
          to: { type: 'string', description: 'Recipient email address.' },
          subject: { type: 'string', description: 'Email subject line.' },
          body: { type: 'string', description: 'Email body text.' },
        },
        required: ['to', 'subject', 'body'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'read_inbox',
      description: 'Fetch the owner\'s most recent unread Gmail messages (sender, subject, snippet).',
      parameters: {
        type: 'object',
        properties: {
          max_results: {
            type: 'number',
            description: 'How many unread emails to fetch. Defaults to 5.',
          },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'add_task',
      description: 'Add a new task/to-do item for the owner to track.',
      parameters: {
        type: 'object',
        properties: {
          description: { type: 'string', description: 'What the task is.' },
          due: {
            type: 'string',
            description: 'Optional free-text due info, e.g. "today 6pm", "tomorrow", "Friday".',
          },
        },
        required: ['description'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'list_tasks',
      description: "List the owner's current pending tasks.",
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'complete_task',
      description:
        'Mark a task as done. Identify it either by its position number in the pending list (as shown by list_tasks) or its exact id.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The task id or its 1-based position in the pending list.',
          },
        },
        required: ['task_id'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'build_project',
      description:
        'Build a small standalone app, tool, script, or game that does NOT need to be live on the internet, and send it to the user as a downloadable zip file on Telegram. Do NOT use this for websites/webpages — use build_website instead whenever the request is for a website, landing page, portfolio site, or anything the user should be able to open via a live URL.',
      parameters: {
        type: 'object',
        properties: {
          request: {
            type: 'string',
            description: "A clear, complete description of what to build, based on the user's request.",
          },
        },
        required: ['request'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'build_website',
      description:
        'Build a brand-new website from a request and deploy it LIVE, returning a real working URL the user can open in a browser immediately — no manual deploy steps, no zip file, no GitHub needed. Use this for ANY request to build/create/make a website, webpage, landing page, or portfolio site — this is the only correct tool for websites, never build_project.',
      parameters: {
        type: 'object',
        properties: {
          request: {
            type: 'string',
            description: "A clear, complete description of the website to build, based on the user's request.",
          },
        },
        required: ['request'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'update_website',
      description:
        'Apply a change to the website already built in this chat and redeploy it to the SAME live URL. Use this for follow-up customization requests (e.g. "make the button blue", "add a contact section") after a website has already been built.',
      parameters: {
        type: 'object',
        properties: {
          instruction: {
            type: 'string',
            description: 'A clear description of the change to make to the existing website.',
          },
        },
        required: ['instruction'],
      },
    },
  },
];

/**
 * Executes a tool call requested by the model and returns a string result
 * to feed back into the conversation.
 * @param {string} name
 * @param {object} args
 * @param {number|string} chatId - Telegram chat to act on
 */
async function executeTool(name, args, chatId) {
  switch (name) {
    case 'set_reminder': {
      const { delay_minutes, message } = args;
      const ms = Math.max(0, Number(delay_minutes)) * 60 * 1000;

      setTimeout(() => {
        sendMessage(chatId, `⏰ Boss, reminder time: ${message}`).catch((err) =>
          console.error('[tools] failed to deliver reminder:', err)
        );
      }, ms);

      return `Reminder ${delay_minutes} nimisham (minutes) kalichu send pannitu iruken for: "${message}"`;
    }
    case 'send_email': {
      const { to, subject, body } = args;
      await gmailService.sendEmail({ to, subject, body });
      return `Email anupitachu (sent) to ${to} with subject "${subject}".`;
    }
    case 'read_inbox': {
      const maxResults = args.max_results || 5;
      const emails = await gmailService.listUnread(maxResults);
      if (emails.length === 0) return 'Inbox la unread emails onnum illa.';
      return emails
        .map((e, i) => `${i + 1}. From: ${e.from} | Subject: ${e.subject} | ${e.snippet}`)
        .join('\n');
    }
    case 'add_task': {
      const { description, due } = args;
      taskService.addTask(description, due);
      return `Task add pannitten: "${description}"${due ? ` (due: ${due})` : ''}`;
    }
    case 'list_tasks': {
      const tasks = taskService.listTasks();
      if (tasks.length === 0) return 'Pending task onnum illa boss, clean!';
      return tasks
        .map((t, i) => `${i + 1}. ${t.description}${t.due ? ` (${t.due})` : ''} [id: ${t.id}]`)
        .join('\n');
    }
    case 'complete_task': {
      const done = taskService.completeTask(args.task_id);
      if (!done) return `Task "${args.task_id}" kaanom, check list_tasks and try again.`;
      return `Sari, "${done.description}" complete ah mark pannitten. 👍`;
    }
    case 'build_project': {
      const result = await buildService.buildProject(args.request);
      const zipBuffer = fs.readFileSync(result.zipPath);
      await sendDocument(chatId, zipBuffer, `jarvis-build-${result.id}.zip`);
      return `Build mudinjachu boss: ${result.summary} (${result.fileCount} file(s)). Zip file already Telegram la anupitten, mela check pannu! 📦`;
    }
    case 'build_website': {
      const { summary, url } = await websiteService.buildAndDeploy(chatId, args.request);
      return `Website live-a deploy pannitten boss! ${summary}\n\n🔗 ${url}\n\nInime edhachum maathanum na sollu, indha same link-la update panniduven.`;
    }
    case 'update_website': {
      const { summary, url } = await websiteService.customizeAndRedeploy(chatId, args.instruction);
      return `Update pannitten boss! ${summary}\n\n🔗 ${url} (same link, refresh pannu pathukalam)`;
    }
    default:
      return `Unknown tool: ${name}`;
  }
}

module.exports = { toolDefinitions, executeTool };
