const GROQ_TRANSCRIBE_URL = 'https://api.groq.com/openai/v1/audio/transcriptions';

/**
 * Transcribes an audio buffer (e.g. a Telegram voice note, .ogg/opus) to text
 * using Groq's hosted Whisper model.
 * @param {Buffer} audioBuffer
 * @param {string} filename - used only to hint the file type, e.g. "voice.ogg"
 * @returns {Promise<string>} the transcribed text
 */
async function transcribeAudio(audioBuffer, filename = 'voice.ogg') {
  const form = new FormData();
  form.append('file', new Blob([audioBuffer]), filename);
  form.append('model', 'whisper-large-v3');

  const res = await fetch(GROQ_TRANSCRIBE_URL, {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}` },
    body: form,
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('[stt] transcription failed:', data);
    throw new Error(data.error?.message || 'Groq transcription failed');
  }
  return data.text;
}

module.exports = { transcribeAudio };
