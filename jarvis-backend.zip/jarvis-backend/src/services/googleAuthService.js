const fs = require('fs');
const path = require('path');

const TOKENS_PATH = path.join(__dirname, '..', '..', 'tokens.json');
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const AUTH_BASE_URL = 'https://accounts.google.com/o/oauth2/v2/auth';

const SCOPES = [
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.readonly',
].join(' ');

function requireEnv() {
  const { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI } = process.env;
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET || !GOOGLE_REDIRECT_URI) {
    throw new Error(
      'Missing GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET / GOOGLE_REDIRECT_URI in .env'
    );
  }
  return { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI };
}

function loadTokens() {
  if (!fs.existsSync(TOKENS_PATH)) return null;
  try {
    return JSON.parse(fs.readFileSync(TOKENS_PATH, 'utf8'));
  } catch (err) {
    console.error('[googleAuth] tokens.json is corrupted:', err.message);
    return null;
  }
}

function saveTokens(tokens) {
  fs.writeFileSync(TOKENS_PATH, JSON.stringify(tokens, null, 2));
}

/**
 * Builds the URL to send the owner to for Google consent.
 */
function getAuthUrl() {
  const { GOOGLE_CLIENT_ID, GOOGLE_REDIRECT_URI } = requireEnv();
  const params = new URLSearchParams({
    client_id: GOOGLE_CLIENT_ID,
    redirect_uri: GOOGLE_REDIRECT_URI,
    response_type: 'code',
    scope: SCOPES,
    access_type: 'offline',
    prompt: 'consent',
  });
  return `${AUTH_BASE_URL}?${params.toString()}`;
}

/**
 * Exchanges an OAuth authorization code for access + refresh tokens,
 * and persists them to tokens.json.
 */
async function exchangeCodeForTokens(code) {
  const { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI } = requireEnv();

  const res = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: GOOGLE_CLIENT_ID,
      client_secret: GOOGLE_CLIENT_SECRET,
      redirect_uri: GOOGLE_REDIRECT_URI,
      grant_type: 'authorization_code',
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('[googleAuth] token exchange failed:', data);
    throw new Error(data.error_description || 'Google token exchange failed');
  }

  const tokens = {
    access_token: data.access_token,
    refresh_token: data.refresh_token, // only returned on first consent
    expiry_date: Date.now() + data.expires_in * 1000,
  };

  // Preserve an existing refresh_token if Google doesn't resend one
  // (it only sends it the very first time you consent).
  const existing = loadTokens();
  if (!tokens.refresh_token && existing?.refresh_token) {
    tokens.refresh_token = existing.refresh_token;
  }

  saveTokens(tokens);
  return tokens;
}

async function refreshAccessToken() {
  const { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET } = requireEnv();
  const tokens = loadTokens();
  if (!tokens?.refresh_token) {
    throw new Error(
      'No refresh token on file. Visit /auth/google to connect your Gmail account first.'
    );
  }

  const res = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      refresh_token: tokens.refresh_token,
      client_id: GOOGLE_CLIENT_ID,
      client_secret: GOOGLE_CLIENT_SECRET,
      grant_type: 'refresh_token',
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('[googleAuth] refresh failed:', data);
    throw new Error(data.error_description || 'Google token refresh failed');
  }

  const updated = {
    ...tokens,
    access_token: data.access_token,
    expiry_date: Date.now() + data.expires_in * 1000,
  };
  saveTokens(updated);
  return updated;
}

/**
 * Returns a valid access token, refreshing it first if it's expired
 * or about to expire in the next 60 seconds.
 */
async function getValidAccessToken() {
  let tokens = loadTokens();
  if (!tokens) {
    throw new Error('Gmail not connected yet. Visit /auth/google first.');
  }
  if (!tokens.expiry_date || Date.now() > tokens.expiry_date - 60_000) {
    tokens = await refreshAccessToken();
  }
  return tokens.access_token;
}

function isConnected() {
  return !!loadTokens()?.refresh_token;
}

module.exports = { getAuthUrl, exchangeCodeForTokens, getValidAccessToken, isConnected };
