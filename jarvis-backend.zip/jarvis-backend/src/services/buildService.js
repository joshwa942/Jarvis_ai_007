const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const MODEL = process.env.GROQ_MODEL || 'llama-3.1-8b-instant';

const BUILDER_SYSTEM_PROMPT = `You are a code-generation engine. Given a build request, output a COMPLETE, working, minimal project.

Respond with ONLY a JSON object, no markdown fences, no commentary, in exactly this shape:
{"summary": "one line describing what you built", "files": [{"path": "relative/file/path.ext", "content": "full file content as a string"}]}

Rules:
- Keep it to the smallest set of files that fully implements the request
- No placeholders, no TODOs, no "add your code here" — every file must be complete and runnable as-is
- For a single HTML page/tool/game, one file is enough: index.html with inline CSS/JS
- For anything needing Node.js, include a minimal package.json with only the dependencies actually used
- Escape all strings correctly so the output is valid JSON
- Never include explanations outside the JSON object`;

/**
 * Asks the model to generate a small project for the given request.
 * @param {string} requestText
 * @returns {Promise<{summary: string, files: {path: string, content: string}[]}>}
 */
async function generateProject(requestText) {
  const res = await fetch(GROQ_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        { role: 'system', content: BUILDER_SYSTEM_PROMPT },
        { role: 'user', content: requestText },
      ],
      response_format: { type: 'json_object' },
      temperature: 0.3,
      max_tokens: 4096,
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('[build] Groq error:', data);
    throw new Error(data.error?.message || 'Build generation failed');
  }

  let parsed;
  try {
    parsed = JSON.parse(data.choices[0].message.content);
  } catch (err) {
    console.error('[build] invalid JSON from model:', data.choices[0].message.content);
    throw new Error('Model did not return valid JSON for the build. Try rephrasing the request.');
  }

  if (!parsed.files || !Array.isArray(parsed.files) || parsed.files.length === 0) {
    throw new Error('Model did not return any files for this build.');
  }

  return parsed;
}

function writeProjectFiles(files, buildDir) {
  fs.mkdirSync(buildDir, { recursive: true });
  for (const file of files) {
    const fullPath = path.join(buildDir, file.path);
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    fs.writeFileSync(fullPath, file.content, 'utf8');
  }
}

function zipProject(buildDir, zipPath) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(zipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => resolve(zipPath));
    archive.on('error', reject);

    archive.pipe(output);
    archive.directory(buildDir, false);
    archive.finalize();
  });
}

/**
 * Generates a project from a request, writes it to disk under builds/<id>/,
 * zips it to builds/<id>.zip, and returns the zip path + metadata.
 * @param {string} requestText
 */
async function buildProject(requestText) {
  const { summary, files } = await generateProject(requestText);

  const id = Date.now().toString(36);
  const buildsRoot = path.join(__dirname, '..', '..', 'builds');
  const buildDir = path.join(buildsRoot, id);
  const zipPath = path.join(buildsRoot, `${id}.zip`);

  writeProjectFiles(files, buildDir);
  await zipProject(buildDir, zipPath);

  return { summary, zipPath, fileCount: files.length, id };
}

module.exports = { buildProject };
