const TELEGRAM_API = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;

if (!process.env.TELEGRAM_BOT_TOKEN) {
  throw new Error('TELEGRAM_BOT_TOKEN is missing from .env');
}

/**
 * Send a text message to a Telegram chat. Tries Markdown formatting first;
 * if the text has unbalanced markdown characters (common with underscores in
 * filenames, code, etc.) Telegram rejects the whole message — so on that
 * specific failure, retry once as plain text instead of losing the reply.
 * @param {number|string} chatId
 * @param {string} text
 */
async function sendMessage(chatId, text) {
  const attempt = async (parseMode) => {
    const body = { chat_id: chatId, text };
    if (parseMode) body.parse_mode = parseMode;

    const res = await fetch(`${TELEGRAM_API}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return res.json();
  };

  let data = await attempt('Markdown');

  if (!data.ok && /can't parse entities/i.test(data.description || '')) {
    console.warn('[telegram] Markdown parse failed, retrying as plain text');
    data = await attempt(null);
  }

  if (!data.ok) {
    console.error('[telegram] sendMessage failed:', data);
    throw new Error(`Telegram API error: ${data.description || 'unknown error'}`);
  }
  return data.result;
}

/**
 * Register the webhook URL with Telegram.
 * Call this once after deploying, via the /setup/webhook route.
 * @param {string} publicUrl - e.g. https://your-domain.com/webhook/telegram
 */
async function setWebhook(publicUrl) {
  const res = await fetch(`${TELEGRAM_API}/setWebhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url: publicUrl }),
  });
  return res.json();
}

async function getWebhookInfo() {
  const res = await fetch(`${TELEGRAM_API}/getWebhookInfo`);
  return res.json();
}

async function sendTyping(chatId) {
  await fetch(`${TELEGRAM_API}/sendChatAction`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, action: 'typing' }),
  }).catch(() => {}); // non-critical, ignore failures
}

/**
 * Downloads a Telegram file (e.g. a voice note) given its file_id.
 * @param {string} fileId
 * @returns {Promise<Buffer>}
 */
async function downloadFile(fileId) {
  const infoRes = await fetch(`${TELEGRAM_API}/getFile?file_id=${fileId}`);
  const infoData = await infoRes.json();
  if (!infoData.ok) {
    console.error('[telegram] getFile failed:', infoData);
    throw new Error(`Telegram getFile error: ${infoData.description || 'unknown error'}`);
  }

  const filePath = infoData.result.file_path;
  const fileUrl = `https://api.telegram.org/file/bot${process.env.TELEGRAM_BOT_TOKEN}/${filePath}`;
  const fileRes = await fetch(fileUrl);
  const arrayBuffer = await fileRes.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

/**
 * Sends an audio buffer as a playable audio message.
 * @param {number|string} chatId
 * @param {Buffer} audioBuffer - MP3 audio data
 * @param {string} filename
 */
async function sendAudio(chatId, audioBuffer, filename = 'reply.mp3') {
  const form = new FormData();
  form.append('chat_id', String(chatId));
  form.append('audio', new Blob([audioBuffer], { type: 'audio/mpeg' }), filename);

  const res = await fetch(`${TELEGRAM_API}/sendAudio`, {
    method: 'POST',
    body: form,
  });

  const data = await res.json();
  if (!data.ok) {
    console.error('[telegram] sendAudio failed:', data);
    throw new Error(`Telegram API error: ${data.description || 'unknown error'}`);
  }
  return data.result;
}

/**
 * Sends a file as a downloadable document.
 * @param {number|string} chatId
 * @param {Buffer} fileBuffer
 * @param {string} filename
 */
async function sendDocument(chatId, fileBuffer, filename) {
  const form = new FormData();
  form.append('chat_id', String(chatId));
  form.append('document', new Blob([fileBuffer]), filename);

  const res = await fetch(`${TELEGRAM_API}/sendDocument`, {
    method: 'POST',
    body: form,
  });

  const data = await res.json();
  if (!data.ok) {
    console.error('[telegram] sendDocument failed:', data);
    throw new Error(`Telegram API error: ${data.description || 'unknown error'}`);
  }
  return data.result;
}

/**
 * Sends a reply the smart way: short answers go as a normal chat message;
 * long answers (over Telegram's practical comfort limit) are sent as a
 * downloadable .txt file instead, so nothing gets cut off.
 * @param {number|string} chatId
 * @param {string} text
 */
async function sendSmartReply(chatId, text) {
  const LONG_ANSWER_THRESHOLD = 3500; // Telegram's hard cap is 4096 chars

  if (text.length <= LONG_ANSWER_THRESHOLD) {
    return sendMessage(chatId, text);
  }

  await sendMessage(
    chatId,
    '📄 Answer romba nedunga irundhadhu boss, so full ah cut aagama file ah anupren!'
  );
  const buffer = Buffer.from(text, 'utf8');
  return sendDocument(chatId, buffer, 'jarvis-answer.txt');
}

module.exports = { sendMessage, setWebhook, getWebhookInfo, sendTyping, downloadFile, sendAudio, sendDocument, sendSmartReply };
