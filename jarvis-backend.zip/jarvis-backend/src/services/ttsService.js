const googleTTS = require('google-tts-api');

/**
 * Converts text into an MP3 audio buffer.
 * Long text is automatically split into chunks (Google TTS has a per-request
 * character limit) and the resulting audio segments are concatenated.
 *
 * Note: `lang: 'en'` is used because JARVIS speaks Tanglish written in
 * English letters — Tamil pronunciation won't be perfect, but it's far more
 * intelligible than forcing Tamil-script phonetics onto Latin-letter text.
 *
 * Text is capped at MAX_SPEECH_CHARS: a voice reply is meant for quick
 * spoken answers, not reading out a full essay. Longer answers should be
 * asked as typed messages instead, where they arrive as a text/file reply.
 *
 * @param {string} text
 * @returns {Promise<Buffer>} MP3 audio buffer
 */
const MAX_SPEECH_CHARS = 1800;

async function synthesizeSpeech(text) {
  let speakText = text;
  if (text.length > MAX_SPEECH_CHARS) {
    speakText =
      text.slice(0, MAX_SPEECH_CHARS) +
      '... Answer innum irukku boss, but romba nedunga irukum, so type pannu full ah padikalam.';
  }

  const chunks = await googleTTS.getAllAudioBase64(speakText, {
    lang: 'en',
    slow: false,
  });

  const buffers = chunks.map((c) => Buffer.from(c.base64, 'base64'));
  return Buffer.concat(buffers);
}

module.exports = { synthesizeSpeech };
