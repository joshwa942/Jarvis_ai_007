const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const MODEL = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';
const NETLIFY_API = 'https://api.netlify.com/api/v1';

const STATE_PATH = path.join(__dirname, '..', '..', 'websites.json');

const SITE_BUILDER_PROMPT = `You are a website-generation engine. Given a request, output a COMPLETE, working static website.

Respond with ONLY a JSON object, no markdown fences, no commentary, in exactly this shape:
{"summary": "one line describing the site", "files": [{"path": "index.html", "content": "..."}]}

Rules:
- Static site only: HTML, CSS, JS. No server-side code, no build step, no external backend.
- One index.html is enough for most requests; split into style.css/script.js only if it
  genuinely helps organize a larger site — always keep index.html as the entry point.
- No placeholders, no "add content here" — every file must be complete, polished, and ready to view
- Make it visually good: real layout, spacing, color choices, not a bare unstyled page
- Escape all strings correctly so the output is valid JSON
- Never include explanations outside the JSON object`;

function loadState() {
  if (!fs.existsSync(STATE_PATH)) return {};
  try {
    return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
  } catch (err) {
    console.error('[website] websites.json is corrupted, starting fresh:', err.message);
    return {};
  }
}

function saveState(state) {
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
}

function getSiteForChat(chatId) {
  const state = loadState();
  return state[String(chatId)] || null;
}

function setSiteForChat(chatId, siteData) {
  const state = loadState();
  state[String(chatId)] = siteData;
  saveState(state);
}

async function callGroqJSON(messages) {
  const res = await fetch(GROQ_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      response_format: { type: 'json_object' },
      temperature: 0.4,
      max_tokens: 4096,
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('[website] Groq error:', data);
    throw new Error(data.error?.message || 'Website generation failed');
  }

  try {
    return JSON.parse(data.choices[0].message.content);
  } catch (err) {
    console.error('[website] invalid JSON from model:', data.choices[0].message.content);
    throw new Error('Model did not return valid JSON. Try rephrasing the request.');
  }
}

/**
 * Generates a brand-new static website from a text request.
 */
async function generateSite(requestText) {
  const parsed = await callGroqJSON([
    { role: 'system', content: SITE_BUILDER_PROMPT },
    { role: 'user', content: requestText },
  ]);

  if (!parsed.files || !Array.isArray(parsed.files) || parsed.files.length === 0) {
    throw new Error('Model did not return any site files.');
  }
  return parsed;
}

/**
 * Regenerates the site's files given the current files and a change request,
 * for iterative customization (e.g. "make the button blue").
 */
async function updateSite(currentFiles, instruction) {
  const currentFilesText = currentFiles
    .map((f) => `--- ${f.path} ---\n${f.content}`)
    .join('\n\n');

  const parsed = await callGroqJSON([
    { role: 'system', content: SITE_BUILDER_PROMPT },
    {
      role: 'user',
      content: `Here is the current website:\n\n${currentFilesText}\n\nApply this change and return the FULL updated set of files (not a diff): ${instruction}`,
    },
  ]);

  if (!parsed.files || !Array.isArray(parsed.files) || parsed.files.length === 0) {
    throw new Error('Model did not return any updated site files.');
  }
  return parsed;
}

/**
 * Zips an array of {path, content} files entirely in memory (no disk writes).
 */
function zipFilesToBuffer(files) {
  return new Promise((resolve, reject) => {
    const archive = archiver('zip', { zlib: { level: 9 } });
    const chunks = [];

    archive.on('data', (chunk) => chunks.push(chunk));
    archive.on('end', () => resolve(Buffer.concat(chunks)));
    archive.on('error', reject);

    for (const file of files) {
      archive.append(file.content, { name: file.path });
    }
    archive.finalize();
  });
}

/**
 * Deploys a zip buffer to Netlify. Creates a new site if siteId is not
 * given, or pushes a new deploy to an existing site otherwise (same URL).
 */
async function deployToNetlify(zipBuffer, siteId) {
  const token = process.env.NETLIFY_API_TOKEN;
  if (!token || token === 'your_netlify_token_here') {
    throw new Error(
      'NETLIFY_API_TOKEN not set in .env. Get a free token at app.netlify.com (User settings > Applications > Personal access tokens).'
    );
  }

  const url = siteId ? `${NETLIFY_API}/sites/${siteId}/deploys` : `${NETLIFY_API}/sites`;

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/zip',
      Authorization: `Bearer ${token}`,
    },
    body: zipBuffer,
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('[website] Netlify deploy failed:', data);
    throw new Error(data.message || 'Netlify deploy failed');
  }

  // A fresh site create returns the site object directly; a deploy to an
  // existing site returns a deploy object with a nested site reference.
  const resolvedSiteId = data.site_id || data.id;
  const resolvedUrl = data.ssl_url || data.url || data.deploy_ssl_url;

  return { siteId: resolvedSiteId, url: resolvedUrl };
}

/**
 * Builds a brand-new website for this chat and deploys it live.
 */
async function buildAndDeploy(chatId, requestText) {
  const { summary, files } = await generateSite(requestText);
  const zipBuffer = await zipFilesToBuffer(files);
  const { siteId, url } = await deployToNetlify(zipBuffer, null);

  setSiteForChat(chatId, { siteId, url, files, summary });
  return { summary, url };
}

/**
 * Applies a customization request to this chat's existing website and
 * redeploys it to the SAME live URL.
 */
async function customizeAndRedeploy(chatId, instruction) {
  const existing = getSiteForChat(chatId);
  if (!existing) {
    throw new Error('No website built yet in this chat. Ask JARVIS to build one first.');
  }

  const { summary, files } = await updateSite(existing.files, instruction);
  const zipBuffer = await zipFilesToBuffer(files);
  const { siteId, url } = await deployToNetlify(zipBuffer, existing.siteId);

  setSiteForChat(chatId, { siteId, url, files, summary });
  return { summary, url };
}

module.exports = { buildAndDeploy, customizeAndRedeploy, getSiteForChat };
