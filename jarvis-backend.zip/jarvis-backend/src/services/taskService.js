const fs = require('fs');
const path = require('path');

const TASKS_PATH = path.join(__dirname, '..', '..', 'tasks.json');

function loadTasks() {
  if (!fs.existsSync(TASKS_PATH)) return [];
  try {
    return JSON.parse(fs.readFileSync(TASKS_PATH, 'utf8'));
  } catch (err) {
    console.error('[tasks] tasks.json is corrupted, starting fresh:', err.message);
    return [];
  }
}

function saveTasks(tasks) {
  fs.writeFileSync(TASKS_PATH, JSON.stringify(tasks, null, 2));
}

/**
 * Adds a new task.
 * @param {string} description
 * @param {string} [due] - optional free-text due info, e.g. "today 6pm", "tomorrow"
 */
function addTask(description, due) {
  const tasks = loadTasks();
  const task = {
    id: Date.now().toString(36),
    description,
    due: due || null,
    completed: false,
    createdAt: new Date().toISOString(),
  };
  tasks.push(task);
  saveTasks(tasks);
  return task;
}

/**
 * Lists tasks. By default only pending (not completed) ones.
 */
function listTasks(includeCompleted = false) {
  const tasks = loadTasks();
  return includeCompleted ? tasks : tasks.filter((t) => !t.completed);
}

/**
 * Marks a task complete. Accepts either the exact task id, or the
 * position number in the pending list (1-based, easier for a user to say).
 */
function completeTask(idOrPosition) {
  const tasks = loadTasks();
  const pending = tasks.filter((t) => !t.completed);

  let target = tasks.find((t) => t.id === String(idOrPosition));

  if (!target) {
    const pos = Number(idOrPosition);
    if (!Number.isNaN(pos) && pos >= 1 && pos <= pending.length) {
      target = pending[pos - 1];
    }
  }

  if (!target) return null;

  target.completed = true;
  target.completedAt = new Date().toISOString();
  saveTasks(tasks);
  return target;
}

function deleteTask(idOrPosition) {
  const tasks = loadTasks();
  const pending = tasks.filter((t) => !t.completed);

  let targetId = tasks.find((t) => t.id === String(idOrPosition))?.id;

  if (!targetId) {
    const pos = Number(idOrPosition);
    if (!Number.isNaN(pos) && pos >= 1 && pos <= pending.length) {
      targetId = pending[pos - 1].id;
    }
  }

  if (!targetId) return false;

  saveTasks(tasks.filter((t) => t.id !== targetId));
  return true;
}

module.exports = { addTask, listTasks, completeTask, deleteTask };
