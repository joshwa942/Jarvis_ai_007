const { toolDefinitions, executeTool } = require('../tools');

const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
// llama-3.3-70b-versatile gives noticeably better general-purpose answers than
// the 8b model, still fast on Groq. Override via GROQ_MODEL in .env if you
// want to try another model listed at console.groq.com/docs/models.
const MODEL = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';

if (!process.env.GROQ_API_KEY || process.env.GROQ_API_KEY === 'your_groq_api_key_here') {
  console.warn(
    '[groq] WARNING: GROQ_API_KEY is not set. Add a real key to .env before sending messages.'
  );
}

const SYSTEM_PROMPT = `You are JARVIS, a personal AI assistant for your owner, reachable over Telegram.

Always reply in Tanglish — natural Tamil-English mixed conversation, written in
English letters (not Tamil script). Sound like a sharp, friendly personal
assistant chatting with a close friend, not a formal corporate bot.

Examples of the tone:
- "Sari boss, reminder set pannitten, 2 nimisham kalichu sollaren"
- "Enna venum sollu, naan pathukaren"
- "Konjam wait pannu, check pandren"

Rules:
- For quick chat, greetings, or simple factual questions, keep replies short
  and punchy, like a real chat message
- For questions that genuinely need depth (explanations, comparisons, how-to,
  analysis, code, long lists) — give the FULL, complete, accurate answer. Do
  not shorten or skip detail just to keep the message short; length is
  handled automatically on the delivery side, so write as much as the
  question actually needs
- Use tools when the user asks for an action (reminders, tasks, email, builds)
- Never switch to pure formal English or pure Tamil script — always Tanglish
- Be genuinely accurate and useful; Tanglish is the voice, never an excuse to
  be vague, wrong, or incomplete`;

/**
 * In-memory conversation history per chat, so JARVIS has short-term memory.
 * For a single-user personal assistant this is fine; swap for a DB/Redis
 * if you need it to persist across server restarts.
 */
const conversations = new Map();

function getHistory(chatId) {
  if (!conversations.has(chatId)) {
    conversations.set(chatId, [{ role: 'system', content: SYSTEM_PROMPT }]);
  }
  return conversations.get(chatId);
}

async function callGroq(messages) {
  const res = await fetch(GROQ_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      tools: toolDefinitions,
      tool_choice: 'auto',
      temperature: 0.4,
      max_tokens: 4096,
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('[groq] API error:', data);
    throw new Error(data.error?.message || 'Groq API request failed');
  }
  return data;
}

/**
 * Handles one user turn end-to-end: adds to history, calls the model,
 * executes any tool calls, and returns the final natural-language reply.
 * Loops to support the model chaining multiple tool calls across turns
 * (e.g. add a task, then confirm by listing tasks), capped to avoid
 * runaway loops.
 * @param {number|string} chatId
 * @param {string} userText
 * @returns {Promise<string>}
 */
async function chat(chatId, userText) {
  const history = getHistory(chatId);
  history.push({ role: 'user', content: userText });

  let data = await callGroq(history);
  let choice = data.choices[0];
  let rounds = 0;
  const MAX_TOOL_ROUNDS = 4;

  while (
    choice.finish_reason === 'tool_calls' &&
    choice.message.tool_calls?.length &&
    rounds < MAX_TOOL_ROUNDS
  ) {
    rounds += 1;
    history.push(choice.message);

    for (const toolCall of choice.message.tool_calls) {
      // Every tool_call MUST get a matching tool-result message, even on
      // failure — otherwise the next API call rejects the whole history
      // with a "tool_calls must be followed by tool messages" error and
      // this chat becomes permanently stuck until restart.
      let result;
      try {
        const args = JSON.parse(toolCall.function.arguments || '{}');
        result = await executeTool(toolCall.function.name, args, chatId);
      } catch (err) {
        console.error(`[groq] tool "${toolCall.function.name}" failed:`, err);
        result = `Error running this tool: ${err.message}. Tell the user in Tanglish that this action failed and why, briefly.`;
      }

      history.push({
        role: 'tool',
        tool_call_id: toolCall.id,
        content: result,
      });
    }

    data = await callGroq(history);
    choice = data.choices[0];
  }

  const reply = choice.message.content || '(no response)';
  history.push({ role: 'assistant', content: reply });

  trimHistory(history);

  return reply;
}

/**
 * Trims history to roughly the last MAX_MESSAGES, but only ever cuts at a
 * 'user' message boundary — never in the middle of an assistant tool_calls
 * message and its tool responses, which would produce an invalid sequence
 * on the next API call.
 */
const MAX_MESSAGES = 40;

function trimHistory(history) {
  if (history.length <= MAX_MESSAGES) return;

  // Search forward from the desired cut point for the next 'user' message
  // to cut at, so we never split a tool_calls/tool pair.
  let cutIndex = history.length - MAX_MESSAGES;
  while (cutIndex < history.length && history[cutIndex].role !== 'user') {
    cutIndex += 1;
  }

  if (cutIndex < history.length) {
    history.splice(1, cutIndex - 1);
  }
  // If no clean 'user' boundary was found, skip trimming this round rather
  // than risk corrupting the sequence — it'll trim next turn instead.
}

module.exports = { chat };
