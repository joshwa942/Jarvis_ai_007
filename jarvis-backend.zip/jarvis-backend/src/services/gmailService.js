const { getValidAccessToken } = require('./googleAuthService');

const GMAIL_API = 'https://gmail.googleapis.com/gmail/v1/users/me';

function base64UrlEncode(str) {
  return Buffer.from(str)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

/**
 * Sends an email via Gmail API.
 * @param {{to: string, subject: string, body: string}} params
 */
async function sendEmail({ to, subject, body }) {
  const accessToken = await getValidAccessToken();

  const rawMessage = [
    `To: ${to}`,
    `Subject: ${subject}`,
    'Content-Type: text/plain; charset="UTF-8"',
    '',
    body,
  ].join('\r\n');

  const res = await fetch(`${GMAIL_API}/messages/send`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw: base64UrlEncode(rawMessage) }),
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('[gmail] sendEmail failed:', data);
    throw new Error(data.error?.message || 'Gmail send failed');
  }
  return data;
}

function getHeader(headers, name) {
  return headers.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value || '';
}

/**
 * Lists the most recent unread emails with subject, sender, and snippet.
 * @param {number} maxResults
 */
async function listUnread(maxResults = 5) {
  const accessToken = await getValidAccessToken();

  const listRes = await fetch(
    `${GMAIL_API}/messages?q=is:unread&maxResults=${maxResults}`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  const listData = await listRes.json();
  if (!listRes.ok) {
    console.error('[gmail] listUnread failed:', listData);
    throw new Error(listData.error?.message || 'Gmail list failed');
  }

  const messages = listData.messages || [];
  if (messages.length === 0) return [];

  const details = await Promise.all(
    messages.map(async (m) => {
      const res = await fetch(
        `${GMAIL_API}/messages/${m.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From`,
        { headers: { Authorization: `Bearer ${accessToken}` } }
      );
      const data = await res.json();
      return {
        id: m.id,
        from: getHeader(data.payload?.headers || [], 'From'),
        subject: getHeader(data.payload?.headers || [], 'Subject'),
        snippet: data.snippet,
      };
    })
  );

  return details;
}

module.exports = { sendEmail, listUnread };
