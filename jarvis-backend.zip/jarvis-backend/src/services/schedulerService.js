const { listTasks } = require('./taskService');
const { sendMessage } = require('./telegramService');

let lastSentDate = null;

function formatDigest(tasks) {
  if (tasks.length === 0) {
    return '🌞 Good morning boss! Inaiku pending task onnum illa. Chill day!';
  }
  const lines = tasks.map(
    (t, i) => `${i + 1}. ${t.description}${t.due ? ` (${t.due})` : ''}`
  );
  return `🌞 Good morning boss! Inaiku pending tasks:\n\n${lines.join('\n')}`;
}

/**
 * Returns { hour, minute, dateKey } for "now" in the given IANA timezone,
 * regardless of what timezone the server's system clock is actually set to.
 * Most cloud hosts (Render, Railway, etc.) run in UTC, so without this a
 * "8 AM" digest would fire at 8 AM UTC = 1:30 PM IST — silently wrong.
 */
function getNowInTimezone(timeZone) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone,
    hour: 'numeric',
    minute: 'numeric',
    hour12: false,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date());

  const get = (type) => parts.find((p) => p.type === type)?.value;
  const hour = Number(get('hour')) % 24; // Intl can return "24" for midnight
  const minute = Number(get('minute'));
  const dateKey = `${get('year')}-${get('month')}-${get('day')}`;

  return { hour, minute, dateKey };
}

/**
 * Starts a lightweight in-process scheduler that checks every minute
 * whether it's time to send the daily task digest, and sends it once
 * per day to the owner's Telegram chat.
 */
function startDailyDigest() {
  const hour = Number(process.env.DAILY_DIGEST_HOUR ?? 8);
  const minute = Number(process.env.DAILY_DIGEST_MINUTE ?? 0);
  const timeZone = process.env.DIGEST_TIMEZONE || 'Asia/Kolkata';
  const ownerId = process.env.OWNER_TELEGRAM_ID;

  if (!ownerId) {
    console.warn(
      '[scheduler] OWNER_TELEGRAM_ID not set — daily digest will not be sent.'
    );
    return;
  }

  setInterval(() => {
    const now = getNowInTimezone(timeZone);

    if (now.hour === hour && now.minute === minute && lastSentDate !== now.dateKey) {
      lastSentDate = now.dateKey;
      const tasks = listTasks();
      sendMessage(ownerId, formatDigest(tasks)).catch((err) =>
        console.error('[scheduler] failed to send daily digest:', err)
      );
    }
  }, 60 * 1000);

  console.log(
    `[scheduler] Daily digest scheduled for ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')} ${timeZone}`
  );
}

module.exports = { startDailyDigest };
