require('dotenv').config();
const express = require('express');
const telegramRoutes = require('./src/routes/telegram');
const authRoutes = require('./src/routes/auth');
const { startDailyDigest } = require('./src/services/schedulerService');

const app = express();
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ status: 'JARVIS backend is running', time: new Date().toISOString() });
});

app.use('/webhook', telegramRoutes);
app.use('/auth', authRoutes);

startDailyDigest();

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`JARVIS backend listening on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/`);
});
